﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class registration : Form
    {
        public registration()
        {
            InitializeComponent();
        }

        private void registration_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you an admin?", "Admin Check", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Check the user's response
            if (result == DialogResult.Yes)
            {
                //MessageBox.Show("well");
                loginAdmin();
            }
            else
            {
                //MessageBox.Show("that's good");
                loginCustomer();
            }

        }
        public void loginAdmin()
        {
           

            login lg = new login();
            lg.Show();
            this.Hide();
        }
        public void loginCustomer()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=database_project;Integrated Security=True"); // Connection String ;Trust Server Certificate=True
            conn.Open();
            //MessageBox.Show("Connection Open");
            SqlCommand cm;
            string fn = textBox1.Text;
            string ln = textBox2.Text;
            string email = textBox3.Text;
            string pass = textBox4.Text;
            string query = "Insert into dbprjt (First_Name, Last_Name, E_mail, pass) values ('" + fn + "','" + ln + "','" + email + "','" + pass + "')";
            cm = new SqlCommand(query, conn);
            cm.ExecuteNonQuery();
            cm.Dispose();
            conn.Close();

            MessageBox.Show("Thanks for your Information");
            login lg = new login();
            lg.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            login lg = new login();
            lg.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login lg = new login();
            lg.Show();
            this.Hide();
        }
    }
}
