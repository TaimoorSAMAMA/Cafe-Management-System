﻿namespace database_project
{
    partial class update_items_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(update_items_form));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsearchitem = new System.Windows.Forms.TextBox();
            this.textcategory = new System.Windows.Forms.TextBox();
            this.txtcategory = new System.Windows.Forms.Label();
            this.textprice = new System.Windows.Forms.TextBox();
            this.txtprice = new System.Windows.Forms.Label();
            this.textitemname = new System.Windows.Forms.TextBox();
            this.txtitemname = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbnupdate = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.Quantity = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Update Item";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(519, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item Name";
            // 
            // txtsearchitem
            // 
            this.txtsearchitem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtsearchitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchitem.Location = new System.Drawing.Point(524, 91);
            this.txtsearchitem.Name = "txtsearchitem";
            this.txtsearchitem.Size = new System.Drawing.Size(189, 26);
            this.txtsearchitem.TabIndex = 2;
            this.txtsearchitem.TextChanged += new System.EventHandler(this.txtsearchitem_TextChanged);
            // 
            // textcategory
            // 
            this.textcategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textcategory.Location = new System.Drawing.Point(98, 340);
            this.textcategory.Name = "textcategory";
            this.textcategory.Size = new System.Drawing.Size(189, 26);
            this.textcategory.TabIndex = 7;
            // 
            // txtcategory
            // 
            this.txtcategory.AutoSize = true;
            this.txtcategory.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcategory.Location = new System.Drawing.Point(93, 310);
            this.txtcategory.Name = "txtcategory";
            this.txtcategory.Size = new System.Drawing.Size(91, 27);
            this.txtcategory.TabIndex = 6;
            this.txtcategory.Text = "Category";
            // 
            // textprice
            // 
            this.textprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textprice.Location = new System.Drawing.Point(370, 340);
            this.textprice.Name = "textprice";
            this.textprice.Size = new System.Drawing.Size(189, 26);
            this.textprice.TabIndex = 9;
            // 
            // txtprice
            // 
            this.txtprice.AutoSize = true;
            this.txtprice.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprice.Location = new System.Drawing.Point(365, 310);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(106, 27);
            this.txtprice.TabIndex = 8;
            this.txtprice.Text = "Item Price";
            this.txtprice.Click += new System.EventHandler(this.label4_Click);
            // 
            // textitemname
            // 
            this.textitemname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textitemname.Location = new System.Drawing.Point(98, 408);
            this.textitemname.Name = "textitemname";
            this.textitemname.Size = new System.Drawing.Size(189, 26);
            this.textitemname.TabIndex = 11;
            // 
            // txtitemname
            // 
            this.txtitemname.AutoSize = true;
            this.txtitemname.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtitemname.Location = new System.Drawing.Point(93, 378);
            this.txtitemname.Name = "txtitemname";
            this.txtitemname.Size = new System.Drawing.Size(112, 27);
            this.txtitemname.TabIndex = 10;
            this.txtitemname.Text = "Item Name";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(18, 123);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(695, 184);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tbnupdate
            // 
            this.tbnupdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbnupdate.BackgroundImage")));
            this.tbnupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tbnupdate.FlatAppearance.BorderSize = 0;
            this.tbnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tbnupdate.Location = new System.Drawing.Point(588, 378);
            this.tbnupdate.Name = "tbnupdate";
            this.tbnupdate.Size = new System.Drawing.Size(125, 46);
            this.tbnupdate.TabIndex = 12;
            this.tbnupdate.Text = "Update";
            this.tbnupdate.UseVisualStyleBackColor = true;
            this.tbnupdate.Click += new System.EventHandler(this.tbnupdate_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(584, 437);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(138, 19);
            this.linkLabel1.TabIndex = 14;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Back to Dashboard";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // txtqty
            // 
            this.txtqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtqty.Location = new System.Drawing.Point(370, 408);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(189, 26);
            this.txtqty.TabIndex = 15;
            // 
            // Quantity
            // 
            this.Quantity.AutoSize = true;
            this.Quantity.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantity.Location = new System.Drawing.Point(365, 378);
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(92, 27);
            this.Quantity.TabIndex = 16;
            this.Quantity.Text = "Quantity";
            // 
            // update_items_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(765, 475);
            this.Controls.Add(this.Quantity);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tbnupdate);
            this.Controls.Add(this.textitemname);
            this.Controls.Add(this.txtitemname);
            this.Controls.Add(this.textprice);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.textcategory);
            this.Controls.Add(this.txtcategory);
            this.Controls.Add(this.txtsearchitem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "update_items_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "update_items";
            this.Load += new System.EventHandler(this.update_items_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsearchitem;
        private System.Windows.Forms.TextBox textcategory;
        private System.Windows.Forms.Label txtcategory;
        private System.Windows.Forms.TextBox textprice;
        private System.Windows.Forms.Label txtprice;
        private System.Windows.Forms.TextBox textitemname;
        private System.Windows.Forms.Label txtitemname;
        private System.Windows.Forms.Button tbnupdate;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.Label Quantity;
    }
}