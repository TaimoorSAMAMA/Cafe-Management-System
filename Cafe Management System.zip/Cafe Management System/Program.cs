﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new login());
            //Application.Run(new adminlogin());
            //Application.Run(new registration());
            //Application.Run(new dashboard());
            //Application.Run(new place_order_form());
            //Application.Run(new add_item_form());
            //Application.Run(new update_items_form());
            //Application.Run(new delect_item_form());
        }
    }
}
