﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace database_project
{
    public partial class add_item_form : Form
    {
        Function fn = new Function();
        string query;

        public add_item_form()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            // Code for guna2Button1_Click
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Code for label1_Click
        }

        private void txtcategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Code for txtcategory_SelectedIndexChanged
        }

        private void btn_add_item_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=database_project;Integrated Security=True";
            string item_name = txtitemname.Text;
            string category = txtcategory.Text;
            string price = txtprice.Text;
            string quantity = txtquantity.Text;
            int itemId;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query1 = "INSERT INTO database_project.dbo.items (category, name, price, quantity) VALUES (@Category, @Name, @Price, @Quantity); SELECT SCOPE_IDENTITY();";
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    cmd.Parameters.AddWithValue("@Category", category);
                    cmd.Parameters.AddWithValue("@Name", item_name);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);

                    itemId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }

            MessageBox.Show("Item Added");
            txtcategory.ResetText();
            txtitemname.Clear();
            txtprice.Clear();
            txtquantity.ResetText();
        }

        private void add_item_form_Load(object sender, EventArgs e)
        {
            // Code for add_item_form_Load
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            Hide();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            place_order_form d = new place_order_form();
            d.Show();
            Hide();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            delect_item_form d = new delect_item_form();
            d.Show();
            Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            inventory i = new inventory();
            i.Show();
            Hide();
            loadData();
        }

        public void loadData()
        {

            // Code for loadData
        }
    }
}
