﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class place_order_form : Form
    {
        Function fn = new Function();
        string query;
        int qty = 0 ;
        int myInt = 0;
        int count = 0;
        public place_order_form()
        {
            InitializeComponent();
        }

        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=Lab9_i210388;Integrated Security=True");

            conn.Open();

            string un = txtSearch.Text;

            
            string selectAllQuery = $"SELECT * from drink "; // WHERE Names = '{un}'

            // Assuming connection is your SqlConnection object
            using (SqlCommand cmd = new SqlCommand(selectAllQuery, conn))
            {
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    MessageBox.Show("Data matched!");

                }
                else
                {
                    MessageBox.Show("Data not matched!");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void place_order_form_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cart c = new Cart();
            c.Show();
            this.Hide();

        }
        protected int n = 0, grand_total = 0;

        private void btn_add_item_Click(object sender, EventArgs e)
        {
            n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = txtitemname.Text;
            dataGridView1.Rows[n].Cells[1].Value = txtprice.Text;
            dataGridView1.Rows[n].Cells[2].Value = txtquantity.Text;
            dataGridView1.Rows[n].Cells[3].Value = txttotal.Text;

            /*grand_total += int.Parse(txttotal.Text);
            labelTotalAmount.Text = "Rs. " + grand_total;*/

            string totalText = txttotal.Text;
            if (int.TryParse(totalText, out int totalAmount))
            {
                grand_total += totalAmount;
                labelTotalAmount.Text = "Rs. " + grand_total;
            }
            else
            {
                // Handle the case where the text is not a valid integer
                MessageBox.Show("Invalid total amount entered.");
            }
            string itemName = txtitemname.Text;
            string price = txtprice.Text;
            string quantity = txtquantity.Text;
            string total = txttotal.Text;

            using (SqlConnection conne = new SqlConnection("Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=database_project;Integrated Security=True"))
            {
                conne.Open();

                // Update the query to insert data into the cart_items table
                string query = "INSERT INTO database_project.dbo.cart_items (itemName, price, quantity, total) VALUES (@ItemName, @Price, @Quantity, @Total)";

                using (SqlCommand cm = new SqlCommand(query, conne))
                {
                    cm.Parameters.AddWithValue("@ItemName", itemName);
                    cm.Parameters.AddWithValue("@Price", price);
                    cm.Parameters.AddWithValue("@Quantity", quantity);
                    cm.Parameters.AddWithValue("@Total", total);

                    cm.ExecuteNonQuery();
                }

                MessageBox.Show("Item Added to Cart");
            }

            int selectedQuantity = int.Parse(quantity);
            txtitemname.Clear();
            txtprice.Clear();
            txtquantity.ResetText();
            txttotal.Clear();

        }
         
        private void txt_itemname_Click(object sender, EventArgs e)
        {

        }

        private void txtcategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string cat = combocategory.Text;
            query = "select * from database_project.dbo.items where category= '" + cat + "' ";
            showItemList(query);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string cat = combocategory.Text;
            query = "select * from database_project.dbo.items where category='" + cat+"'and name like'"+txtSearch.Text+"%'";
            showItemList(query);
        }

        private void showItemList(string query)
        {
            listBox1.Items.Clear();
            DataSet ds = fn.GetData(query);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBox1.Items.Add(ds.Tables[0].Rows[i][1].ToString());
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtquantity.ResetText();
            txttotal.Clear();

            string text = listBox1.GetItemText(listBox1.SelectedItem);
            txtitemname.Text = text;




            query = "select price from database_project.dbo.items where name= '" + text + "' ";
            DataSet ds = fn.GetData(query);

            try
            {
                txtprice.Text = ds.Tables[0].Rows[0][0].ToString();
            }
            catch
            {

            }

        }

        private void txtquantity_ValueChanged(object sender, EventArgs e)
        {

            Int64 qty = Int64.Parse(txtquantity.Value.ToString());
            Int64 price = Int64.Parse(txtprice.Text);

            txttotal.Text = (qty * price).ToString();
        }
        int amount;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                amount = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    string itemName = selectedRow.Cells[0].Value.ToString();
                    string total = selectedRow.Cells[3].Value.ToString();

                    DeleteItemFromCart(itemName, total);

                    dataGridView1.Rows.RemoveAt(selectedRow.Index);

                    
                    
                    OpenForm2();

                    if (labelTotalAmount.Text == "0")
                    {
                        labelTotalAmount.Text = "0";
                    }

                    MessageBox.Show("Item deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteItemFromCart(string itemName, string total)
        {
            using (SqlConnection conne = new SqlConnection("Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=database_project;Integrated Security=True"))
            {
                conne.Open();

                // Update the query to delete data from the cart_items table
                string query = "DELETE FROM database_project.dbo.cart_items WHERE itemName = @ItemName";

                using (SqlCommand cm = new SqlCommand(query, conne))
                {
                    cm.Parameters.AddWithValue("@ItemName", itemName);
                    cm.ExecuteNonQuery();

                    // Subtract the total amount of the deleted item from grand_total
                    int totalAmount = int.Parse(total);
                    grand_total -= totalAmount;
                    labelTotalAmount.Text = "Rs. " + grand_total;
                }
            }
        }

        

        private void labelTotalAmount_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Payment p = new Payment();
            p.Show();
            
            this.Hide();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OpenForm2()
        {
            Payment py = new Payment(labelTotalAmount.Text);
         
        }
    }
}
