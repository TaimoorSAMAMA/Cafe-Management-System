﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace database_project
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        public login(string user)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            registration r = new registration();
            r.Show();
            this.Hide();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=Lab9_i210388;Integrated Security=True");

            conn.Open();

            string un = textBox2.Text;
            string pass = textBox3.Text;

            // Fetch data from the Facebook_Users table
            string selectQuery = $"SELECT * FROM database_project.dbo.dbprjt WHERE First_Name = '{un}' AND pass = '{pass}'";

            using (SqlCommand cmd = new SqlCommand(selectQuery, conn))
            {
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    MessageBox.Show("Successfully Login");
                    
                    dashboard d = new dashboard("User");
                    d.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Wrong Username and Password!");
                    login lg = new login();
                    lg.Show();

                }
            }
            
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            dashboard d = new dashboard("Guest");
            d.Show();
            this.Hide();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
                adminlogin lg = new adminlogin();
                lg.Show();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            adminlogin al = new adminlogin();
            al.Show();
            this.Hide();
        }
    }
}
