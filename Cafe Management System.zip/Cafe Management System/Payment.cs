﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Payment : Form
    {
        Function fn = new Function();
        string query;
        decimal sum = 0;
        private string receivedtotalprice;
        public Payment()
        {
            InitializeComponent();
        }
        public Payment(string myInteger)
        {
            InitializeComponent();
            receivedtotalprice = myInteger;

            
        }

        private void combocategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Payment_Load(object sender, EventArgs e)
        {
            
            // Assuming fn.GetData(query) returns a DataSet with the correct data
            query = "SELECT itemName, price, quantity, total FROM database_project.dbo.cart_items";
            DataSet ds = fn.GetData(query);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0];
            }
            else
            {
                return;
            }

            int columnIndex = 3;

            // Get the sum of values in the 3rd column
            decimal sum = CalculateColumnSum(dataGridView1, columnIndex);

            // Display the sum in the label
            labelTotalAmount.Text = $"Total: " + sum;
        }
        
        private decimal CalculateColumnSum(DataGridView dataGridView, int columnIndex)
        {
            

            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Cells[columnIndex].Value != null && decimal.TryParse(row.Cells[columnIndex].Value.ToString(), out decimal cellValue))
                {
                    sum += cellValue;
                }
            }

            return sum;
        }

        private void labelTotalAmount_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Display a pop-up message with the total amount
            MessageBox.Show($"Price: {sum}\nThanks for your purchase!", "Payment Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Delete items from the cart_items table
            DeleteItemsFromCart();

            // Clear the DataGridView
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();

            // Clear the total amount label
            labelTotalAmount.Text = "Total: 0";
            DialogResult result = MessageBox.Show("Do you want to make another order?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // If yes, go to the place_order_form
                place_order_form pof = new place_order_form();
                pof.Show();
                this.Hide();
            }
            else
            {
                // If no, display a thanks message
                MessageBox.Show("Thank you for your order!", "Thanks", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close(); // Close the Payment form or perform other actions as needed
            }
        }

        private void DeleteItemsFromCart()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-1G00HHE\\SQLEXPRESS;Initial Catalog=database_project;Integrated Security=True"))
                {
                    conn.Open();

                    // Assuming you have an identifier for each row (e.g., item ID), replace "ID" with your actual column name
                    string deleteQuery = "DELETE FROM database_project.dbo.cart_items";

                    using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting items from cart: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
