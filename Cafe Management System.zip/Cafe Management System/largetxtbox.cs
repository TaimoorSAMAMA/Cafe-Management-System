﻿namespace database_project
{
    internal class largetxtbox
    {
    }
}