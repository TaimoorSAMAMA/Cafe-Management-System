﻿namespace database_project
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_add_to_cart = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.LinkLabel();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_remove_item = new System.Windows.Forms.Button();
            this.btn_update_item = new System.Windows.Forms.Button();
            this.btn_add_items = new System.Windows.Forms.Button();
            this.btn_place_order = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bannername = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Green;
            this.panel1.Controls.Add(this.btn_add_to_cart);
            this.panel1.Controls.Add(this.btn_logout);
            this.panel1.Controls.Add(this.btn_exit);
            this.panel1.Controls.Add(this.btn_remove_item);
            this.panel1.Controls.Add(this.btn_update_item);
            this.panel1.Controls.Add(this.btn_add_items);
            this.panel1.Controls.Add(this.btn_place_order);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 514);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btn_add_to_cart
            // 
            this.btn_add_to_cart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_add_to_cart.BackgroundImage")));
            this.btn_add_to_cart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_add_to_cart.FlatAppearance.BorderSize = 0;
            this.btn_add_to_cart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add_to_cart.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_to_cart.ForeColor = System.Drawing.Color.White;
            this.btn_add_to_cart.Location = new System.Drawing.Point(48, 391);
            this.btn_add_to_cart.Name = "btn_add_to_cart";
            this.btn_add_to_cart.Size = new System.Drawing.Size(97, 43);
            this.btn_add_to_cart.TabIndex = 21;
            this.btn_add_to_cart.Text = "View Cart";
            this.btn_add_to_cart.UseVisualStyleBackColor = true;
            this.btn_add_to_cart.Click += new System.EventHandler(this.btn_add_to_cart_Click);
            // 
            // btn_logout
            // 
            this.btn_logout.AutoSize = true;
            this.btn_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.LinkColor = System.Drawing.Color.White;
            this.btn_logout.Location = new System.Drawing.Point(63, 474);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(56, 19);
            this.btn_logout.TabIndex = 5;
            this.btn_logout.TabStop = true;
            this.btn_logout.Text = "LogOut";
            this.btn_logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btn_logout_LinkClicked);
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.Color.Red;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Location = new System.Drawing.Point(3, 4);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(31, 31);
            this.btn_exit.TabIndex = 4;
            this.btn_exit.Text = "X";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_remove_item
            // 
            this.btn_remove_item.BackColor = System.Drawing.Color.Green;
            this.btn_remove_item.BackgroundImage = global::database_project.Properties.Resources.green_button_clip_art_click_here_button_removebg_preview;
            this.btn_remove_item.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_remove_item.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_remove_item.FlatAppearance.BorderSize = 0;
            this.btn_remove_item.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_remove_item.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove_item.ForeColor = System.Drawing.Color.White;
            this.btn_remove_item.Location = new System.Drawing.Point(0, 315);
            this.btn_remove_item.Name = "btn_remove_item";
            this.btn_remove_item.Size = new System.Drawing.Size(202, 60);
            this.btn_remove_item.TabIndex = 3;
            this.btn_remove_item.Text = "Remove Items";
            this.btn_remove_item.UseVisualStyleBackColor = false;
            this.btn_remove_item.Click += new System.EventHandler(this.btn_remove_item_Click);
            // 
            // btn_update_item
            // 
            this.btn_update_item.BackColor = System.Drawing.Color.Green;
            this.btn_update_item.BackgroundImage = global::database_project.Properties.Resources.green_button_clip_art_click_here_button_removebg_preview;
            this.btn_update_item.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_update_item.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_update_item.FlatAppearance.BorderSize = 0;
            this.btn_update_item.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_update_item.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update_item.ForeColor = System.Drawing.Color.White;
            this.btn_update_item.Location = new System.Drawing.Point(-2, 249);
            this.btn_update_item.Name = "btn_update_item";
            this.btn_update_item.Size = new System.Drawing.Size(202, 60);
            this.btn_update_item.TabIndex = 2;
            this.btn_update_item.Text = "Update Items";
            this.btn_update_item.UseVisualStyleBackColor = false;
            this.btn_update_item.Click += new System.EventHandler(this.btn_update_item_Click);
            // 
            // btn_add_items
            // 
            this.btn_add_items.BackColor = System.Drawing.Color.Green;
            this.btn_add_items.BackgroundImage = global::database_project.Properties.Resources.green_button_clip_art_click_here_button_removebg_preview;
            this.btn_add_items.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_add_items.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_add_items.FlatAppearance.BorderSize = 0;
            this.btn_add_items.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add_items.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_items.ForeColor = System.Drawing.Color.White;
            this.btn_add_items.Location = new System.Drawing.Point(-2, 183);
            this.btn_add_items.Name = "btn_add_items";
            this.btn_add_items.Size = new System.Drawing.Size(202, 60);
            this.btn_add_items.TabIndex = 1;
            this.btn_add_items.Text = "Add Items";
            this.btn_add_items.UseVisualStyleBackColor = false;
            this.btn_add_items.Click += new System.EventHandler(this.btn_add_items_Click);
            // 
            // btn_place_order
            // 
            this.btn_place_order.BackColor = System.Drawing.Color.Green;
            this.btn_place_order.BackgroundImage = global::database_project.Properties.Resources.green_button_clip_art_click_here_button_removebg_preview;
            this.btn_place_order.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_place_order.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_place_order.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_place_order.FlatAppearance.BorderSize = 0;
            this.btn_place_order.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_place_order.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_place_order.ForeColor = System.Drawing.Color.White;
            this.btn_place_order.Location = new System.Drawing.Point(0, 117);
            this.btn_place_order.Name = "btn_place_order";
            this.btn_place_order.Size = new System.Drawing.Size(202, 60);
            this.btn_place_order.TabIndex = 0;
            this.btn_place_order.Text = "Place Order";
            this.btn_place_order.UseVisualStyleBackColor = false;
            this.btn_place_order.Click += new System.EventHandler(this.btn_place_order_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Controls.Add(this.bannername);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panel2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(212, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(780, 514);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // bannername
            // 
            this.bannername.AutoSize = true;
            this.bannername.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bannername.Location = new System.Drawing.Point(304, 364);
            this.bannername.Name = "bannername";
            this.bannername.Size = new System.Drawing.Size(217, 67);
            this.bannername.TabIndex = 5;
            this.bannername.Text = "SI Cafe";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(383, 292);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 50);
            this.label1.TabIndex = 4;
            this.label1.Text = "To";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(144, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(560, 225);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1004, 538);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dashboard";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_place_order;
        private System.Windows.Forms.Button btn_remove_item;
        private System.Windows.Forms.Button btn_update_item;
        private System.Windows.Forms.Button btn_add_items;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.LinkLabel btn_logout;
        private System.Windows.Forms.Label bannername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_add_to_cart;
    }
}