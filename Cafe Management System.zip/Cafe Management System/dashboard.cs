﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class dashboard : Form
    {
        Function fn = new Function();
        string query;
        public dashboard()
        {
            InitializeComponent();
        }

        public dashboard(String user)
        {
            InitializeComponent();

            if(user == "Guest")
            {
                btn_add_items.Hide();
                btn_update_item.Hide();
                btn_remove_item.Hide();
                btn_add_to_cart.Hide();
            }
            if (user == "Admin")
            {
                btn_place_order.Hide();
                btn_add_items.Show();
                btn_update_item.Show();
                btn_remove_item.Show();
                btn_add_to_cart.Hide();

                panel1.BackColor = Color.Blue;
                btn_add_items.BackColor = Color.Blue;
                btn_update_item.BackColor = Color.Blue;
                btn_remove_item.BackColor = Color.Blue;
            }
            if (user == "User")
            {
                btn_place_order.Show();
                btn_add_items.Hide();
                btn_update_item.Hide();
                btn_remove_item.Hide();
                btn_add_to_cart.Show();
            }
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_place_order_Click(object sender, EventArgs e)
        {
            place_order_form pof = new place_order_form();
            pof.Show();
            this.Hide();
        }

        private void btn_add_items_Click(object sender, EventArgs e)
        {
            add_item_form aif = new add_item_form();
            aif.Show();
            this.Hide();
        }

        private void btn_update_item_Click(object sender, EventArgs e)
        {
            update_items_form aif = new update_items_form();
            aif.Show();
            this.Hide();
        }

        private void btn_remove_item_Click(object sender, EventArgs e)
        {
            delect_item_form dif = new delect_item_form();
            dif.Show();
            this.Hide();
        }

        private void btn_add_to_cart_Click(object sender, EventArgs e)
        {
            Cart C = new Cart();
            C.Show();
            this.Hide();

        }
    }
}
