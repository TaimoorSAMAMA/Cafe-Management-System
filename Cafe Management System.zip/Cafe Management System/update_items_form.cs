﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class update_items_form : Form
    {
        Function fn = new Function();
        string query;
        string query1;
        string qur;
        public update_items_form()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

       
        private void txtlargebox_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtsearchitem_TextChanged(object sender, EventArgs e)
        {
            query = "select * from database_project.dbo.items where name like '" + txtsearchitem.Text + "%' ";
            DataSet ds = fn.GetData(query);
            dataGridView1.DataSource = ds.Tables[0];
        }
        private void update_items_form_Load(object sender, EventArgs e)
        {
            loadData();
        }

        public void loadData()
        {
            query = "select * from database_project.dbo.items";
            DataSet ds = fn.GetData(query);
            dataGridView1.DataSource = ds.Tables[0];
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            qur = "select * from database_project.dbo.items where name like '" + txtsearchitem.Text + "%'";
            DataSet ds = fn.GetData(qur);
            dataGridView1.DataSource = ds.Tables[0];
        }
        int id;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            String category = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            String name = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            String quantity = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            int price  = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());

          
            textcategory.Text = category;
            textitemname.Text = name;
            textprice.Text = price.ToString();
            txtqty.Text = quantity;
        }

        private void tbnupdate_Click(object sender, EventArgs e)
        {
            query = "Update database_project.dbo.items set name='" + textitemname.Text+"',category='"+ textcategory.Text+ "', quantity= '" + txtqty.Text+"',price='"+textprice.Text+ "' where id= "+ id +" ";
            
            fn.SetData(query);
            
            loadData();


            textcategory.Clear();
            textitemname.Clear();
            textprice.Clear();
            txtqty.Clear();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();
        }
    }
}

