﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class adminlogin : Form
    {
        public adminlogin()
        {
            InitializeComponent();
        }

        public adminlogin(string user)
        {
            if (user == "Admin")
            {
            }
        }
        private void adminlogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard("Admin");
            if (textBox2.Text == "SICafe" && textBox3.Text == "0388")
            {
                d.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Data not matched!");
                adminlogin lg = new adminlogin();
                lg.Show();
            }
            
        }
    }
}
